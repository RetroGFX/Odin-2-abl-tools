#!/bin/sh

# Backup abl_a and abl_b
mkdir -p /sdcard/backup
dd if=/dev/block/by-name/abl_a of="/sdcard/backup/abl_a.img" bs=1M
dd if=/dev/block/by-name/abl_b of="/sdcard/backup/abl_b.img" bs=1M

dd if="/sdcard/odin2_custom_abl/abl_signed.elf" of=/dev/block/by-name/abl_a bs=1M
dd if="/sdcard/odin2_custom_abl/abl_signed.elf" of=/dev/block/by-name/abl_b bs=1M
