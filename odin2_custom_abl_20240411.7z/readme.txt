Extract odin2_custom_abl to the root of Android internal storage

Then use "Odin settings" -> "Run script as Root" to run the "backup_and_flash.sh" script

The original ABL will be backed up to /sdcard/backup

Config: https://renegade-project.tech/en/ayn-odin2/linuxloader